// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../../nonnon/game/helper.c"
#include "../../nonnon/game/transition.c"

#include "../../nonnon/win32/gdi.c"




#define N_TYPING_CANVAS_SIZE ( 256 )


#define N_TYPING_CANVAS_COLOR_DARK n_bmp_rgb( 111,111,111 )
#define N_TYPING_CANVAS_COLOR_LITE n_bmp_rgb( 222,222,222 )


#define N_TYPING_MODE_LOCK_MSEC ( 500 )


#define N_TYPING_MODE_WARM_UP ( 0 )
#define N_TYPING_MODE_TRAINER ( 1 )
#define N_TYPING_MODE_FREE    ( 2 )




NSString *n_typing_trainer_warm_up_table[] = {

	@"f", @"g", @"f", @"g",
	@"f", @"d", @"f", @"d",
	@"f", @"s", @"f", @"s",
	@"f", @"a", @"f", @"a",

	@"Space",

	@"j", @"h", @"j", @"h",
	@"j", @"k", @"j", @"k",
	@"j", @"l", @"j", @"l",

	@"Space",

	@"f", @"b", @"f", @"b",
	@"f", @"v", @"f", @"v",
	@"f", @"c", @"f", @"c",
	@"f", @"x", @"f", @"x",
	@"f", @"z", @"f", @"z",

	@"Space",

	@"j", @"n", @"j", @"n",
	@"j", @"m", @"j", @"m",

	@"Space",

	@"f", @"t", @"f", @"t",
	@"f", @"r", @"f", @"r",
	@"f", @"e", @"f", @"e",
	@"f", @"w", @"f", @"w",
	@"f", @"q", @"f", @"q",

	@"Space",

	@"j", @"y", @"j", @"y",
	@"j", @"u", @"j", @"u",
	@"j", @"i", @"j", @"i",
	@"j", @"o", @"j", @"o",
	@"j", @"p", @"j", @"p",

	@"Space",

	@"f", @"1", @"f", @"1",
	@"f", @"2", @"f", @"2",
	@"f", @"3", @"f", @"3",
	@"f", @"4", @"f", @"4",
	@"f", @"5", @"f", @"5",
	@"f", @"6", @"f", @"6",

	@"Space",

	@"j", @"7", @"j", @"7",
	@"j", @"8", @"j", @"8",
	@"j", @"9", @"j", @"9",
	@"j", @"0", @"j", @"0",

	@"Return",

	NULL

};

NSString*
n_typing_trainer_warm_up( void )
{

	static int i = 0;

	NSString *nsstr = n_typing_trainer_warm_up_table[ i ];

	i++;

	if ( n_typing_trainer_warm_up_table[ i ] == NULL )
	{
		i = 0;
	}


	return nsstr;
}

NSString*
n_typing_trainer_shuffle( void )
{

	NSString *nsstr;

	int random = n_game_random( 10 );

	if ( random == 0 )
	{
		int r = n_game_random( 3 );
		if ( r == 0 )
		{
			nsstr = @"Space";
		} else
		if ( r == 1 )
		{
			nsstr = @"Backspace";
		} else {
			nsstr = @"Return";
		}
	} else
	if ( random < 4 )
	{
		int f = '0';
		int t = '9';

		int r = t - f;

		char str[ 2 ] = { f + n_game_random( r ), N_STRING_CHAR_NUL };

		nsstr = n_mac_str2nsstring( str );
	} else {
		int a = 'a';
		int z = 'z';

		int r = z - a;

		char str[ 2 ] = { a + n_game_random( r ), N_STRING_CHAR_NUL };

		nsstr = n_mac_str2nsstring( str );
	}


	return nsstr;
}




typedef struct {

	NonnonGame   *self;
	NSPoint       pt;
	n_bmp         canvas;
	n_posix_bool  refresh;

	n_type_gfx    sx,sy;

	int           mode;

	//u32           lock;

	int           baseline;

	n_posix_bool  is_single_char;

	n_posix_bool  trainer_input;
	int           trainer_index;

	NSString     *string_cur;
	NSString     *string_prv;
	NSString     *string_ans;

	n_posix_bool  transition_onoff;
	n_bmp         transition_bmp_old;
	n_bmp         transition_bmp_new;
	n_type_real   transition_percent;
	n_posix_bool  transition_event;
	n_posix_bool  transition_special;
	int           transition_blink_phase;
	u32           transition_msec;

	NSMenuItem   *n_menu_warm_up;
	NSMenuItem   *n_menu_trainer;
	NSMenuItem   *n_menu_free;

} n_typing;




u32
n_typing_color_bg( n_typing *p )
{
	if ( p->mode == N_TYPING_MODE_WARM_UP )
	{
		return N_TYPING_CANVAS_COLOR_DARK;
	} else
	if ( p->mode == N_TYPING_MODE_TRAINER )
	{
		return N_TYPING_CANVAS_COLOR_DARK;
	} else {
		return N_TYPING_CANVAS_COLOR_LITE;
	}
}

u32
n_typing_color_fg( n_typing *p )
{
	if ( p->mode == N_TYPING_MODE_WARM_UP )
	{
		return n_bmp_white;
	} else
	if ( p->mode == N_TYPING_MODE_TRAINER )
	{
		return N_TYPING_CANVAS_COLOR_LITE;
	} else {
		return N_TYPING_CANVAS_COLOR_DARK;
	}
}

void
n_typing_gdi( n_typing *p, n_bmp *bmp, NSString *str )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	n_type_gfx factor = 1;

	if ( p->is_single_char )
	{
		factor = 1;
	} else {
		factor = 2;
		if ( [str length] >= 3 )
		{
			factor = ceil( (CGFloat) [str length] / 2 );
		}
	}

	gdi.sx                  = N_TYPING_CANVAS_SIZE;
	gdi.sy                  = N_TYPING_CANVAS_SIZE;
	gdi.scale               = N_GDI_SCALE_AUTO;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base                = n_posix_literal( "" );
	gdi.base_index          = 0;
	gdi.base_color_bg       = n_typing_color_bg( p );
	gdi.base_color_fg       = n_typing_color_fg( p );
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	if ( p->mode == N_TYPING_MODE_WARM_UP )
	{
		gdi.base_style = N_GDI_BASE_VERTICAL;
	}

	gdi.text                = n_mac_nsstring2str( str );
	gdi.text_font           = n_posix_literal( "Trebuchet MS" );
	gdi.text_size           = ( N_TYPING_CANVAS_SIZE / 2 ) / factor;
	gdi.text_style          = p->baseline;
	gdi.text_color_main     = n_typing_color_fg( p );


	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	n_string_free( gdi.text );


	return;
}




void
n_typing_sound_play( n_mac_sound2 *p )
{

	n_mac_sound2_stop( p );
	n_mac_sound2_play( p );

	return;
}




// [!] : this is important to play

n_mac_sound2 n_typing_snd[ 2 + 1 + 6 ];




#define n_typing_zero( p ) n_memory_zero( p, sizeof( n_typing ) )

void
n_typing_init( n_typing *p )
{

	// Global

	n_bmp_safemode = n_posix_false;

	n_bmp_transparent_onoff_default = n_posix_false;

	//n_bmp_flip_onoff = n_posix_true;

	n_random_shuffle();


	// Instance

	n_bmp_new( &p->canvas, N_TYPING_CANVAS_SIZE, N_TYPING_CANVAS_SIZE );


	n_mac_sound2_init( &n_typing_snd[ 0 ], @"answer_o"       , @"wav" );
	n_mac_sound2_init( &n_typing_snd[ 1 ], @"answer_x"       , @"wav" );

	n_mac_sound2_init( &n_typing_snd[ 2 ], @"carriage_return", @"mp3" );

	n_mac_sound2_init( &n_typing_snd[ 3 ], @"typewriter"     , @"wav" );
	n_mac_sound2_init( &n_typing_snd[ 4 ], @"typewriter"     , @"wav" );
	n_mac_sound2_init( &n_typing_snd[ 5 ], @"typewriter"     , @"wav" );
	n_mac_sound2_init( &n_typing_snd[ 6 ], @"typewriter"     , @"wav" );
	n_mac_sound2_init( &n_typing_snd[ 7 ], @"typewriter"     , @"wav" );
	n_mac_sound2_init( &n_typing_snd[ 8 ], @"typewriter"     , @"wav" );


	return;
}

void
n_typing_exit( n_typing *p )
{
	return;
}

void
n_typing_loop( n_typing *p )
{

	if (
		( p->mode == N_TYPING_MODE_WARM_UP )
		||
		( p->mode == N_TYPING_MODE_TRAINER )
	)
	{
		if ( p->trainer_input )
		{
			p->trainer_input = n_posix_false;

			//p->lock = n_posix_tickcount() + N_TYPING_MODE_LOCK_MSEC;

			if ( [p->string_cur compare:p->string_ans] == 0 )
			{
				if ( p->mode == N_TYPING_MODE_WARM_UP )
				{
					p->string_cur = n_typing_trainer_warm_up();
				} else {
					p->string_cur = n_typing_trainer_shuffle();
				}

				p->is_single_char = ( 1 == [p->string_cur length] );

				n_typing_sound_play( &n_typing_snd[ 0 ] );

				p->transition_event = n_posix_true;
			} else {
				n_typing_sound_play( &n_typing_snd[ 1 ] );
			}
		}
	} else
	if ( p->mode == N_TYPING_MODE_FREE )
	{
		if ( p->trainer_input )
		{
			p->trainer_input = n_posix_false;

			//p->lock = n_posix_tickcount() + ( N_TYPING_MODE_LOCK_MSEC / 2 );

			if ( [p->string_cur compare:@"Return"] == 0 )
			{
//static int i = 0; NSLog( @"Return : %d", i ); i++;
				n_typing_sound_play( &n_typing_snd[ 2 ] );
			} else {
				static int jam = 0;
				n_typing_sound_play( &n_typing_snd[ 2 + 1 + ( jam % 6 ) ] );
				jam++;
			}

			p->transition_event = n_posix_true;
		}
	}



	// [!] : Shared

	if ( p->transition_event )
	{
		p->transition_event = n_posix_false;

		p->transition_onoff = n_posix_true;

		if ( p->transition_special )
		{
			n_bmp_carboncopy( &p->canvas, &p->transition_bmp_old );

			n_bmp_new( &p->transition_bmp_new, N_TYPING_CANVAS_SIZE, N_TYPING_CANVAS_SIZE );
			n_bmp_flush( &p->transition_bmp_new, n_typing_color_bg( p ) );
		} else
		if ( 0 != [p->string_cur compare:p->string_prv] )
		{
			n_bmp_carboncopy( &p->canvas, &p->transition_bmp_old );

			n_typing_gdi( p, &p->transition_bmp_new, p->string_cur );
		} else {
			p->transition_blink_phase = 1;
		}
	}

	if ( p->transition_blink_phase == 1 )
	{
		p->transition_blink_phase = 2;

		n_bmp_carboncopy( &p->canvas, &p->transition_bmp_old );

		n_bmp_new( &p->transition_bmp_new, N_TYPING_CANVAS_SIZE, N_TYPING_CANVAS_SIZE );
		n_bmp_flush( &p->transition_bmp_new, n_typing_color_bg( p ) );
	} else
	if ( p->transition_blink_phase == 2 )
	{
		if ( p->transition_onoff == n_posix_false )
		{
			p->transition_blink_phase = 0;

			p->transition_onoff = n_posix_true;

			n_bmp_new( &p->transition_bmp_old, N_TYPING_CANVAS_SIZE, N_TYPING_CANVAS_SIZE );
			n_bmp_flush( &p->transition_bmp_old, n_typing_color_bg( p ) );

			n_typing_gdi( p, &p->transition_bmp_new, p->string_cur );
		}
	}

	if ( p->transition_onoff )
	{
		n_posix_bool ret = n_game_transition
		(
			&p->canvas,
			&p->transition_bmp_old, 
			&p->transition_bmp_new,
			 p->transition_msec,
			&p->transition_percent,
			N_GAME_TRANSITION_FADE
		);

		if ( ret )
		{
			p->transition_onoff = n_posix_false;

			n_bmp_free( &p->transition_bmp_old );
			n_bmp_free( &p->transition_bmp_new );

			p->string_prv = p->string_cur;

			p->transition_special = n_posix_false;
		}

		p->refresh = n_posix_true;
	}


	return;
}


