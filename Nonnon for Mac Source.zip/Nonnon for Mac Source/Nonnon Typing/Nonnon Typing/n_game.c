// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File


// [!] : Usage
//
//	1 : replace your NSView (Custom View) to NonnonGame
//	2 : IB : right pane : "Custom Class", "Class", set "NonnonGame"
//	3 : modify behavior


// [!] : trouble shooter
//
//	[ drawRect is not called at redraw ]
//
//		a : call [_n_game display];
//		b : see your @property and connect(DnD) to UI on the Xib canvas
//		c : layer may cause




#ifndef _H_NONNON_MAC_NONNON_GAME
#define _H_NONNON_MAC_NONNON_GAME




#import <Cocoa/Cocoa.h>


#include "../../nonnon/mac/_mac.c"
#include "../../nonnon/mac/image.c"
#include "../../nonnon/mac/sound.c"
#include "../../nonnon/mac/window.c"




@interface NonnonGame : NSView

@end




#include "n_typing.c"




@implementation NonnonGame {

	n_typing typing;

}


- (instancetype)initWithCoder:(NSCoder *)coder
{
//NSLog( @"initWithCoder" );

	self = [super initWithCoder:coder];
	if ( self )
	{
		n_typing_zero( &typing );
		n_typing_init( &typing );
//NSLog( @"%d %d", typing.sx, typing.sy );

		typing.self = self;

		typing.sx = N_BMP_SX( &typing.canvas );
		typing.sy = N_BMP_SY( &typing.canvas );

		n_mac_timer_init( self, @selector( n_timer_method ), 1 );
	}


	return self;
}


- (void) n_mac_game_canvas_resize:(NSWindow*)window width:(n_type_gfx)sx height:(n_type_gfx)sy
{

	if ( sx == -1 ) { sx = typing.sx; }
	if ( sy == -1 ) { sy = typing.sy; }

	NSSize size = NSMakeSize( sx,sy );

	[window setContentMinSize:size];
	[window setContentMaxSize:size];

	NSRect rect = NSMakeRect( 0,0,sx,sy );
	[self setFrame:rect];

	[window setContentSize:size];

	// [x] : Sonoma : black flicker happens
	//typing.refresh = TRUE;
	//[window display];

}




- (BOOL) isFlipped
{
	return YES;
}




- (void) n_timer_method
{

	static u32 timer = 0;
	if ( n_game_timer( &timer, 12 ) )
	{
		n_typing_loop( &typing );
	}


	if ( typing.refresh )
	{
		typing.refresh = FALSE;

		[self display];
	}

}




- (void)drawRect:(NSRect)rect
{
//NSLog( @"drawRect" );

	n_type_gfx sx = N_BMP_SX( &typing.canvas );
	n_type_gfx sy = N_BMP_SY( &typing.canvas );

	rect = NSMakeRect( 0,0,sx,sy );

	n_mac_image_nbmp_direct_draw( &typing.canvas, &rect, n_posix_false );

}




- (void) NonnonTypingFlush
{
	n_typing *p = &typing;

	if ( p->mode == N_TYPING_MODE_WARM_UP )
	{
		u32 f = n_typing_color_bg( p );
		u32 t = n_typing_color_fg( p );

		n_bmp_flush_gradient( &p->canvas, f, t, N_BMP_GRADIENT_VERTICAL );
	} else {
		n_bmp_flush( &p->canvas, n_typing_color_bg( p ) );
	}

}




- (void) NonnonTypingSettingsWrite
{

	n_typing *p = &typing;

	NSString *nsstr = @"";

	if ( p->mode == N_TYPING_MODE_WARM_UP )
	{
		nsstr = @"Warm-up";
	} else
	if ( p->mode == N_TYPING_MODE_TRAINER )
	{
		nsstr = @"Trainer";
	} else
	if ( p->mode == N_TYPING_MODE_FREE )
	{
		nsstr = @"Free";
	}

	n_mac_settings_write( @"mode", nsstr );

}




- (void) NonnonTypingMenuSet:(int) mode menu:(NSMenuItem*)menu
{

	n_typing *p = &typing;

	if ( mode == N_TYPING_MODE_WARM_UP )
	{
		p->n_menu_warm_up = menu;
	} else
	if ( mode == N_TYPING_MODE_TRAINER )
	{
		p->n_menu_trainer = menu;
	} else
	if ( mode == N_TYPING_MODE_FREE )
	{
		p->n_menu_free    = menu;
	}// else

}




- (void) NonnonTypingModeSet:(int) mode forced:(n_posix_bool)forced
{

	n_typing *p = &typing;;

	if ( ( p->mode != mode )||( forced ) )
	{
		p->mode = mode;

		if ( mode == N_TYPING_MODE_WARM_UP )
		{
			[p->n_menu_warm_up setState:NSControlStateValueOn ];
			[p->n_menu_trainer setState:NSControlStateValueOff];
			[p->n_menu_free    setState:NSControlStateValueOff];

			p->string_prv = @"";
			p->string_cur = @"Return";

			p->is_single_char = ( 1 == [p->string_cur length] );

			p->transition_msec = 500;
		} else
		if ( mode == N_TYPING_MODE_TRAINER )
		{
			[p->n_menu_warm_up setState:NSControlStateValueOff];
			[p->n_menu_trainer setState:NSControlStateValueOn ];
			[p->n_menu_free    setState:NSControlStateValueOff];

			p->string_prv = @"";
			p->string_cur = @"Return";

			p->is_single_char = ( 1 == [p->string_cur length] );

			p->transition_msec = 500;
		} else
		if ( mode == N_TYPING_MODE_FREE )
		{
			[p->n_menu_warm_up setState:NSControlStateValueOff];
			[p->n_menu_trainer setState:NSControlStateValueOff];
			[p->n_menu_free    setState:NSControlStateValueOn ];

			p->transition_special = n_posix_true;

			p->transition_msec = 200;
		}

		p->transition_event = n_posix_true;

		[self display];
	}

}




- (BOOL)acceptsFirstResponder
{
//NSLog(@"acceptsFirstResponder");
	return YES;
}

- (BOOL)becomeFirstResponder
{
//NSLog(@"becomeFirstResponder");
        return YES;
}

- (void) keyDown : (NSEvent*) event
{
//NSLog( @"%d : %@", event.keyCode, [event characters] ); return;


	if (
		( typing.mode == N_TYPING_MODE_WARM_UP )
		||
		( typing.mode == N_TYPING_MODE_TRAINER )
	)
	{
		//if ( typing.lock > n_posix_tickcount() ) { typing.string_ans = @""; return; }
		if ( typing.transition_onoff ) { typing.string_ans = @""; return; }
	}


	if ( typing.mode == N_TYPING_MODE_FREE )
	{
		typing.is_single_char = n_posix_false;
	}


	typing.baseline = N_GDI_TEXT_MAC_BASELINE;


	NSString *nsstring;

	switch( event.keyCode ) {

	case N_MAC_KEYCODE_SPACE:

		nsstring = @"Space";

	break;

	case N_MAC_KEYCODE_RETURN:

		nsstring = @"Return";

	break;

	case N_MAC_KEYCODE_BACKSPACE:

		nsstring = @"Backspace";

	break;

	case N_MAC_KEYCODE_MENU:

		// [x] : crash 

		nsstring = @"Menu";

	break;

	case N_MAC_KEYCODE_ESCAPE:

		// [x] : crash 

		nsstring = @"Esc";

	break;

	case N_MAC_KEYCODE_ENTER:

		// [x] : crash 

		nsstring = @"Enter";

	break;

	case N_MAC_KEYCODE_TAB:

		nsstring = @"Tab";

	break;

	case N_MAC_KEYCODE_ARROW_UP:

		typing.baseline = 0;

		nsstring = @"↑";

	break;

	case N_MAC_KEYCODE_ARROW_DOWN:

		typing.baseline = 0;

		nsstring = @"↓";

	break;

	case N_MAC_KEYCODE_ARROW_LEFT:

		typing.baseline = 0;

		nsstring = @"←";

	break;

	case N_MAC_KEYCODE_ARROW_RIGHT:

		typing.baseline = 0;

		nsstring = @"→";

	break;

	case N_MAC_KEYCODE_HOME:

		nsstring = @"Home";

	break;

	case N_MAC_KEYCODE_END:

		nsstring = @"End";

	break;

	case N_MAC_KEYCODE_INSERT:

		nsstring = @"Insert";

	break;

	case N_MAC_KEYCODE_DELETE:

		nsstring = @"Delete";

	break;

	case N_MAC_KEYCODE_PRTSCN:

		nsstring = @"PrtSc";

	break;

	case N_MAC_KEYCODE_PAGE_UP:

		nsstring = @"Page Up";

	break;

	case N_MAC_KEYCODE_PAGE_DOWN:

		nsstring = @"Page Down";

	break;

	case N_MAC_KEYCODE_F1:

		nsstring = @"F1";

	break;

	case N_MAC_KEYCODE_F2:

		nsstring = @"F2";

	break;

	case N_MAC_KEYCODE_F3:

		nsstring = @"F3";

	break;

	case N_MAC_KEYCODE_F4:

		nsstring = @"F4";

	break;

	case N_MAC_KEYCODE_F5:

		nsstring = @"F5";

	break;

	case N_MAC_KEYCODE_F6:

		nsstring = @"F6";

	break;

	case N_MAC_KEYCODE_F7:

		nsstring = @"F7";

	break;

	case N_MAC_KEYCODE_F8:

		nsstring = @"F8";

	break;

	case N_MAC_KEYCODE_F9:

		nsstring = @"F9";

	break;

	case N_MAC_KEYCODE_F10:

		nsstring = @"F10";

	break;

	case N_MAC_KEYCODE_F12:

		nsstring = @"F12";

	break;

	default:

		if ( typing.mode == N_TYPING_MODE_FREE )
		{
			typing.is_single_char = n_posix_true;

			// [!] : for "$"
			if ( event.modifierFlags & NSEventModifierFlagShift )
			{
				typing.baseline = 0;
			}
		}

		nsstring = [event characters];

	break;

	}


	if (
		( typing.mode == N_TYPING_MODE_WARM_UP )
		||
		( typing.mode == N_TYPING_MODE_TRAINER )
	)
	{

		typing.trainer_input = n_posix_true;

		typing.string_ans = nsstring;

	} else
	if ( typing.mode == N_TYPING_MODE_FREE )
	{

		typing.trainer_input = n_posix_true;

		typing.string_prv = typing.string_cur;
		typing.string_cur = nsstring;

	}

}


@end




#endif // _H_NONNON_MAC_NONNON_GAME


